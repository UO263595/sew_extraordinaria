package test.util;

import java.util.List;

import static org.junit.Assert.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumUtils {

	/**
	 * Aborta si el "texto" no est� presente en la p�gina actual
	 * 
	 * @param driver: apuntando al navegador abierto actualmente.
	 * @param texto:  texto a buscar
	 */
	static public void textoPresentePagina(WebDriver driver, String texto) {
		List<WebElement> list = driver.findElements(By.xpath("//*[contains(text(),'" + texto + "')]"));
		assertTrue("�Texto " + texto + " no localizado!", list.size() > 0);
	}

	/**
	 * Aborta si el "texto" est� presente en la p�gina actual
	 * 
	 * @param driver: apuntando al navegador abierto actualmente.
	 * @param texto:  texto a buscar
	 */
	static public void textoNoPresentePagina(WebDriver driver, String texto) {
		List<WebElement> list = driver.findElements(By.xpath("//*[contains(text(),'" + texto + "')]"));
		assertTrue("�Texto " + texto + " a�n presente !", list.size() == 0);
	}

	/**
	 * Aborta si el "texto" est� presente en la p�gina actual tras timeout segundos.
	 * 
	 * @param driver:  apuntando al navegador abierto actualmente.
	 * @param texto:   texto a buscar
	 * @param timeout: el tiempo m�ximo que se esperar� por la aparici�n del texto a
	 *                 buscar
	 */
	static public boolean EsperaCargaPaginaNoTexto(WebDriver driver, String texto, int timeout) {
		Boolean resultado = (new WebDriverWait(driver, timeout)).until(
				ExpectedConditions.invisibilityOfElementLocated(By.xpath("//*[contains(text(),'" + texto + "')]")));

		return resultado;
	}

	/**
	 * Espera por la visibilidad de un elemento/s en la vista actualmente cargandose
	 * en driver. Para ello se emplear� una consulta xpath.
	 * 
	 * @param driver:  apuntando al navegador abierto actualmente.
	 * @param xpath:   consulta xpath.
	 * @param timeout: el tiempo m�ximo que se esperar� por la aparici�n del
	 *                 elemento a buscar con xpath
	 * @return Se retornar� la lista de elementos resultantes de la b�squeda con
	 *         xpath.
	 */
	static public List<WebElement> EsperaCargaPaginaxpath(WebDriver driver, String xpath, int timeout) {
		WebElement resultado = (new WebDriverWait(driver, timeout))
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		assertTrue(resultado != null);
		List<WebElement> elementos = driver.findElements(By.xpath(xpath));

		return elementos;
	}

	/**
	 * Espera por la visibilidad de un elemento/s en la vista actualmente cargandose
	 * en driver. Para ello se emplear� una consulta xpath seg�n varios criterios..
	 * 
	 * @param driver:   apuntando al navegador abierto actualmente.
	 * @param criterio: "id" or "class" or "text" or "@attribute" or "free". Si el
	 *                  valor de criterio es free es una expresion xpath completa.
	 * @param text:     texto correspondiente al criterio.
	 * @param timeout:  el tiempo m�ximo que se esperar� por la apareci�n del
	 *                  elemento a buscar con criterio/text.
	 * @return Se retornar� la lista de elementos resultantes de la b�squeda.
	 */
	static public List<WebElement> EsperaCargaPagina(WebDriver driver, String criterio, String text, int timeout) {
		String busqueda;
		if (criterio.equals("id"))
			busqueda = "//*[contains(@id,'" + text + "')]";
		else if (criterio.equals("class"))
			busqueda = "//*[contains(@class,'" + text + "')]";
		else if (criterio.equals("text"))
			busqueda = "//*[contains(text(),'" + text + "')]";
		else if (criterio.equals("free"))
			busqueda = text;
		else
			busqueda = "//*[contains(" + criterio + ",'" + text + "')]";

		return EsperaCargaPaginaxpath(driver, busqueda, timeout);
	}
}
