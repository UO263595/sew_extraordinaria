package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import tests.pageobjects.PO_AddMessageView;
import tests.pageobjects.PO_AddOfferView;
import tests.pageobjects.PO_ListOffersView;
import tests.pageobjects.PO_LoginView;
import tests.pageobjects.PO_NavView;
import tests.pageobjects.PO_SignupView;
import tests.pageobjects.PO_View;

//ordenamos las pruebas por el nombre del m�todo
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ApplicationTest {
	static String PathFirefox65 = "C:\\Program Files\\Mozilla Firefox\\firefox.exe";
	static String Geckdriver024 = "C:\\Users\\Usuario\\Desktop\\entrega-1\\geckodriver024win64.exe";

	static WebDriver driver = getDriver(PathFirefox65, Geckdriver024);
	static String URL = "http://localhost:8081/";

	public static WebDriver getDriver(String PathFirefox, String Geckdriver) {
		System.setProperty("webdriver.firefox.bin", PathFirefox);
		System.setProperty("webdriver.gecko.driver", Geckdriver);
		WebDriver driver = new FirefoxDriver();
		return driver;
	}

	/**
	 * Antes de cada prueba se navega al URL home de la aplicaci�n
	 */
	@Before
	public void setUp() {
		// dos opciones para la carga de datos, comentar/descomentar una u otra a
		// conveniencia
		driver.navigate().to(URL);
		// ### Carga manual de datos de prueba ###
		// initdb();
		// ### Carga autom�tica de datos de prueba ###
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "admin@email.com", "admin");
		driver.navigate().to(URL + "initBD");
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");
	}

	/**
	 * Inicializar la base de datos
	 */
	public void initdb() {
		// ELIMINAR DATOS ANTIGUOS
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "admin@email.com", "admin");
		// Clicamos en la opci�n de men� de usuarios
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'users-menu')]/a");
		elements.get(0).click();
		// Contamos el n�mero de filas
		int numberOfUsers = (PO_View.checkElement(driver, "free", "//tbody/tr") != null)
				? PO_View.checkElement(driver, "free", "//tbody/tr").size()
				: 0;
		// Marcamos los checkbox
		for (int i = 1; i <= numberOfUsers; i++) {
			elements = PO_View.checkElement(driver, "free", "//*[@id='tableUsers']/tbody/tr[" + i + "]/td[1]/input");
			elements.get(0).click();
		}
		// Pulsamos el bot�n de borrado
		By boton = By.className("btn");
		driver.findElement(boton).click();
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");

		// INTRODUCIR DATOS NUEVOS
		// USUARIO 1
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "susana@email.com", "Susana", "Ivanov Villarejo", "123456", "123456");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 1", "Descripci�n oferta 1", "10.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 2", "Descripci�n oferta 2", "20.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 3", "Descripci�n oferta 3", "30.0");
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");

		// USUARIO 2
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "miriam@email.com", "Miriam", "Aguayo Barrero", "123456", "123456");
		// Comprobamos que entramos en la secci�n privada
		assertNotNull(PO_View.checkElement(driver, "free", "//a[contains(@id,'authenticatedUser')]"));
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 4", "Descripci�n oferta 4", "40.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 5", "Descripci�n oferta 5", "50.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 6", "Descripci�n oferta 6", "60.0");
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");

		// USUARIO 3
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "javier@email.com", "Javier", "Romero Rial", "123456", "123456");
		// Comprobamos que entramos en la secci�n privada
		assertNotNull(PO_View.checkElement(driver, "free", "//a[contains(@id,'authenticatedUser')]"));
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 7", "Descripci�n oferta 7", "70.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 8", "Descripci�n oferta 8", "80.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 9", "Descripci�n oferta 9", "90.0");
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");

		// USUARIO 4
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "cristobal@email.com", "Cristobal", "Baena Magro", "123456", "123456");
		// Comprobamos que entramos en la secci�n privada
		assertNotNull(PO_View.checkElement(driver, "free", "//a[contains(@id,'authenticatedUser')]"));
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 10", "Descripci�n oferta 10", "100.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 11", "Descripci�n oferta 11", "110.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 12", "Descripci�n oferta 12", "120.0");
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");

		// USUARIO 5
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "domingo@email.com", "Domingo", "March Mula", "123456", "123456");
		// Comprobamos que entramos en la secci�n privada
		assertNotNull(PO_View.checkElement(driver, "free", "//a[contains(@id,'authenticatedUser')]"));
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 13", "Descripci�n oferta 13", "130.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 14", "Descripci�n oferta 14", "140.0");
		// Clicamos en la opci�n de men� de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Oferta 15", "Descripci�n oferta 15", "150.0");
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");

		// MENSAJE
		// ir a la direcci�n del cliente
		driver.navigate().to(URL + "cliente.html?w=login");
		// Iniciamos sesi�n
		PO_LoginView.fillForm(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers')]/a");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillFormClient(driver, "Oferta 15");
		// Clicamos en el bot�n de abrir conversaci�n
		elements = PO_View.checkElement(driver, "free", "//*[@id='conversation-Oferta 15']");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddMessageView.fillForm(driver, "Hola");
		// Comprobamos que se ha enviado el mensaje
		assertNotNull(PO_SignupView.checkKey(driver, "Mensaje enviado con �xito"));
		// Comprobamos que el mensaje aparece en la lista
		assertNotNull(PO_SignupView.checkKey(driver, "Hola"));
	}

	/**
	 * Despu�s de cada prueba se borran las cookies del navegador y los datos de la
	 * Base de Datos
	 */
	@After
	public void tearDown() {
		driver.navigate().to(URL);
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "admin@email.com", "admin");
		driver.navigate().to(URL + "deleteBD");
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");
		driver.manage().deleteAllCookies();
	}

	/**
	 * Antes de la primera prueba
	 */
	@BeforeClass
	static public void begin() {
	}

	/**
	 * Al finalizar la �ltima prueba
	 */
	@AfterClass
	static public void end() {
		// Cerramos el navegador al finalizar las pruebas
		driver.quit();
	}

	/**
	 * PR01. Registro de Usuario con datos v�lidos
	 */
	@Test
	public void PR01() {
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "user@email.com", "User", "Test User", "123456", "123456");
		// Comprobamos que entramos en la secci�n privada
		assertNotNull(PO_View.checkElement(driver, "free", "//*[@id='authenticatedUser']"));
	}

	// /
	/**
	 * PR02A. Registro de Usuario con datos inv�lidos (email vac�o)
	 */
	@Test
	public void PR02A() {
		// EMAIL VAC�O
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "", "User", "Test User", "123456", "123456");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "Debe rellenar el campo de email"));
	}

	/**
	 * PR02B. Registro de Usuario con datos inv�lidos (nombre vac�o)
	 */
	@Test
	public void PR02B() {
		// NOMBRE VAC�O
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "user@email.com", "", "Test User", "123456", "123456");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "Debe rellenar el campo de nombre"));
	}

	/**
	 * PR02C. Registro de Usuario con datos inv�lidos (apellidos vac�os)
	 */
	@Test
	public void PR02C() {
		// APELLIDOS VAC�OS
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "user@email.com", "User", "", "123456", "123456");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "Debe rellenar el campo de apellidos"));
	}

	/**
	 * PR03. Registro de Usuario con datos inv�lidos (repetici�n de contrase�a
	 * inv�lida)
	 */
	@Test
	public void PR03() {
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "user@email.com", "User", "Test User", "123456", "654321");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "La repetici�n de la contrase�a es incorrecta"));
	}

	/**
	 * PR04. Registro de Usuario con datos inv�lidos (email existente)
	 */
	@Test
	public void PR04() {
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "signup", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_SignupView.fillForm(driver, "admin@email.com", "Susana", "Ivanov Villarejo", "123456", "123456");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "El email est� repetido en la base de datos"));
	}

	/**
	 * PR05A. Inicio de sesi�n con datos v�lidos (administrador)
	 */
	@Test
	public void PR05A() {
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "login", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, "admin@email.com", "admin");
		// Comprobamos que entramos en la secci�n privada
		assertNotNull(PO_View.checkElement(driver, "free", "//a[contains(@id,'authenticatedUser')]"));
	}

	/**
	 * PR05B. Inicio de sesi�n con datos v�lidos (usuario est�ndar)
	 */
	@Test
	public void PR05B() {
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "login", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, "susana@email.com", "123456");
		// Comprobamos que entramos en la secci�n privada
		assertNotNull(PO_View.checkElement(driver, "free", "//a[contains(@id,'authenticatedUser')]"));
	}

	/**
	 * PR06. Inicio de sesi�n con datos v�lidos (usuario est�ndar, email existente,
	 * pero contrase�a incorrecta)
	 */
	@Test
	public void PR06() {
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "login", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, "susana@email.com", "654321");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "Email o contrase�a incorrectos"));
	}

	/**
	 * PR07. Inicio de sesi�n con datos inv�lidos (usuario est�ndar, campo email y
	 * contrase�a vac�os)
	 */
	@Test
	public void PR07() {
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "login", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, "", "");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "Debe rellenar el campo de email"));
		assertNotNull(PO_SignupView.checkKey(driver, "Debe rellenar el campo de contrase�a"));
	}

	/**
	 * PR08. Inicio de sesi�n con datos inv�lidos (usuario est�ndar, email no
	 * existente en la aplicaci�n)
	 */
	@Test
	public void PR08() {
		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "login", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, "inexistente@email.com", "123456");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "Email o contrase�a incorrectos"));
	}

	/**
	 * PR09. Hacer click en la opci�n de salir de sesi�n y comprobar que se redirige
	 * a la p�gina de inicio de sesi�n (Login)
	 */
	@Test
	public void PR09() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Pulsamos el bot�n de desconexi�n
		PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");
		// Comprobamos que hemos vuelto a la secci�n de login
		assertNotNull(PO_View.checkElement(driver, "free", "//h2[contains(@id,'identificationSection')]"));
	}

	/**
	 * PR10. Comprobar que el bot�n cerrar sesi�n no est� visible si el usuario no
	 * est� autenticado
	 */
	@Test
	public void PR10() {
		// Comprobamos que el bot�n no est� visible
		assertTrue(PO_View.checkNotElement(driver, "Desconectar"));
	}

	/**
	 * PR11. Mostrar el listado de usuarios y comprobar que se muestran todos los
	 * que existen en el sistema
	 */
	@Test
	public void PR11() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "admin@email.com", "admin");
		// Clicamos en la opci�n de menu de usuarios
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'users-menu')]/a");
		elements.get(0).click();
		// Contamos el n�mero de filas de usuarios y lo comparamos con el n�mero de
		// usuarios totales
		elements = PO_View.checkElement(driver, "free", "//tbody/tr");
		// Comparamos con el n�mero esperado de usuarios (sin administradores)
		assertEquals(5, elements.size());
	}

	/**
	 * PR12. Ir a la lista de usuarios, borrar el primer usuario de la lista,
	 * comprobar que la lista se actualiza y que el usuario desaparece
	 */
	@Test
	public void PR12() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "admin@email.com", "admin");
		// Clicamos en la opci�n de men� de usuarios
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'users-menu')]/a");
		elements.get(0).click();
		// Guardamos el email de usuario a borrar
		String userToDelete = PO_View.checkElement(driver, "free", "//*[@id=\"tableUsers\"]/tbody/tr[1]/td[2]").get(0)
				.getText();
		// Marcamos el checkbox
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableUsers']/tbody/tr[1]/td[1]/input");
		elements.get(0).click();
		// Pulsamos el bot�n de borrado
		By boton = By.className("btn");
		driver.findElement(boton).click();
		// Comprobamos que el usuario ya no aparece en la lista
		assertTrue(PO_View.checkNotElement(driver, userToDelete));
	}

	/**
	 * PR13. Ir a la lista de usuarios, borrar el �ltimo usuario de la lista,
	 * comprobar que la lista se actualiza y que el usuario desaparece
	 */
	@Test
	public void PR13() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "admin@email.com", "admin");
		// Clicamos en la opci�n de men� de usuarios
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'users-menu')]/a");
		elements.get(0).click();
		// Buscamos la posici�n del �ltimo usuario
		int position = PO_View.checkElement(driver, "free", "//tbody/tr").size();
		// Guardamos el email de usuario a borrar
		String userToDelete = PO_View
				.checkElement(driver, "free", "//*[@id=\"tableUsers\"]/tbody/tr[" + position + "]/td[2]").get(0)
				.getText();
		// Marcamos el checkbox
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableUsers']/tbody/tr[" + position + "]/td[1]/input");
		elements.get(0).click();
		// Pulsamos el bot�n de borrado
		By boton = By.className("btn");
		driver.findElement(boton).click();
		// Comprobamos que el usuario ya no aparece en la lista
		assertTrue(PO_View.checkNotElement(driver, userToDelete));
	}

	/**
	 * PR14. Ir a la lista de usuarios, borrar 3 usuarios, comprobar que la lista se
	 * actualiza y que los usuarios desaparecen
	 */
	@Test
	public void PR14() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "admin@email.com", "admin");
		// Clicamos en la opci�n de men� de usuarios
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'users-menu')]/a");
		elements.get(0).click();
		// Buscamos la posici�n del �ltimo usuario
		int lastPosition = PO_View.checkElement(driver, "free", "//tbody/tr").size();
		// Buscamos la posici�n de un usuario intermedio
		int middlePosition = lastPosition / 2;
		// Guardamos los email de los usuarios a borrar
		String firstUserToDelete = PO_View.checkElement(driver, "free", "//*[@id=\"tableUsers\"]/tbody/tr[1]/td[2]")
				.get(0).getText();
		String middleUserToDelete = PO_View
				.checkElement(driver, "free", "//*[@id=\"tableUsers\"]/tbody/tr[" + middlePosition + "]/td[2]").get(0)
				.getText();
		String lastUserToDelete = PO_View
				.checkElement(driver, "free", "//*[@id=\"tableUsers\"]/tbody/tr[" + lastPosition + "]/td[2]").get(0)
				.getText();
		// Marcamos los checkbox
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableUsers']/tbody/tr[1]/td[1]/input");
		elements.get(0).click();
		elements = PO_View.checkElement(driver, "free",
				"//*[@id='tableUsers']/tbody/tr[" + middlePosition + "]/td[1]/input");
		elements.get(0).click();
		elements = PO_View.checkElement(driver, "free",
				"//*[@id='tableUsers']/tbody/tr[" + lastPosition + "]/td[1]/input");
		elements.get(0).click();
		// Pulsamos el bot�n de borrado
		By boton = By.className("btn");
		driver.findElement(boton).click();
		// Comprobamos que los usuarios ya no aparecen en la lista
		assertTrue(PO_View.checkNotElement(driver, firstUserToDelete));
		assertTrue(PO_View.checkNotElement(driver, middleUserToDelete));
		assertTrue(PO_View.checkNotElement(driver, lastUserToDelete));
	}

	/**
	 * PR15. Ir al formulario de alta de oferta, rellenarla con datos v�lidos y
	 * pulsar el bot�n Submit. Comprobar que la oferta sale en el listado de ofertas
	 * de dicho usuario
	 */
	@Test
	public void PR15() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de men� de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "Raqueta", "Raqueta de tenis con funda. Poco uso.", "20");
		// Realizamos la b�squeda de la oferta a�adida
		PO_ListOffersView.fillForm(driver, "Raqueta");
		// Comprobamos que la oferta se ha a�adido correctamente
		assertNotNull(PO_View.checkElement(driver, "text", "Raqueta"));
	}

	/**
	 * PR16. Ir al formulario de alta de oferta, rellenarla con datos inv�lidos
	 * (campo t�tulo vac�o y precio negativo) y pulsar el bot�n Submit. Comprobar
	 * que se muestra los mensajes de error
	 */
	@Test
	public void PR16() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de agregar ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/add')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddOfferView.fillForm(driver, "", "Raqueta de tenis con funda. Poco uso.", "-20");
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "Debe rellenar el campo de t�tulo"));
		assertNotNull(PO_SignupView.checkKey(driver, "El precio debe ser un n�mero positivo"));
	}

	/**
	 * PR17. Mostrar el listado de ofertas para dicho usuario y comprobar que se
	 * muestran todas los que existen para este usuario
	 */
	@Test
	public void PR17() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/own/list')]");
		elements.get(0).click();
		// Comprobamos que el n�mero de ofertas es el del usuario
		elements = PO_View.checkElement(driver, "free", "//tbody/tr");
		assertEquals(3, elements.size());
	}

	/**
	 * PR18. Ir a la lista de ofertas, borrar la primera oferta de la lista,
	 * comprobar que la lista se actualiza y que la oferta desaparece
	 */
	@Test
	public void PR18() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/own/list')]");
		elements.get(0).click();
		// Borrar la primera oferta
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableOffers']/tbody/tr[1]/td[4]/form/button");
		elements.get(0).click();
		// Comprobamos que la oferta ya no aparece en la lista
		assertTrue(PO_View.checkNotElement(driver, "Oferta 1"));
	}

	/**
	 * PR19. Ir a la lista de ofertas, borrar la �ltima oferta de la lista,
	 * comprobar que la lista se actualiza y que la oferta desaparece
	 */
	@Test
	public void PR19() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/own/list')]");
		elements.get(0).click();
		// Borrar la �ltima oferta
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableOffers']/tbody/tr[3]/td[4]/form/button");
		elements.get(0).click();
		// Comprobamos que la oferta ya no aparece en la lista
		assertTrue(PO_View.checkNotElement(driver, "Oferta 3"));
	}

	/**
	 * PR20. Hacer una b�squeda con el campo vac�o y comprobar que se muestra la
	 * p�gina que corresponde con el listado de las ofertas existentes en el sistema
	 */
	@Test
	public void PR20() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/list')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillForm(driver, "");
		// Contamos el total de filas de todas las p�ginas
		int rows = 0;

		for (int i = 1; i <= 3; i++) {
			elements = PO_View.checkElement(driver, "free", "//*[@id='pi-" + i + "']/a");
			elements.get(0).click();
			rows += (PO_View.checkElement(driver, "free", "//tbody/tr") != null)
					? PO_View.checkElement(driver, "free", "//tbody/tr").size()
					: 0;
		}

		// Comparamos las filas con el total de ofertas
		assertEquals(15, rows);
	}

	/**
	 * PR21. Hacer una b�squeda escribiendo en el campo un texto que no exista y
	 * comprobar que se muestra la p�gina que corresponde, con la lista de ofertas
	 * vac�a
	 */
	@Test
	public void PR21() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/list')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillForm(driver, "Oferta no existente");
		// Contamos el total de filas
		int rows = (PO_View.checkElement(driver, "free", "//tbody/tr") != null)
				? PO_View.checkElement(driver, "free", "//tbody/tr").size()
				: 0;
		// Comprobamos que la lista est� vac�a
		assertEquals(0, rows);
	}

	/**
	 * PR22. Hacer una b�squeda escribiendo en el campo un texto en min�scula o
	 * may�scula y comprobar que se muestra la p�gina que corresponde, con la lista
	 * de ofertas que contengan dicho texto, independientemente que el t�tulo est�
	 * almacenado en min�sculas o may�scula
	 */
	@Test
	public void PR22() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/list')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillForm(driver, "oferta 6");
		// Contamos el total de filas
		int rows = (PO_View.checkElement(driver, "free", "//tbody/tr") != null)
				? PO_View.checkElement(driver, "free", "//tbody/tr").size()
				: 0;
		// Comprobamos que la lista est� vac�a
		assertEquals(1, rows);
		// Rellenamos el formulario
		PO_ListOffersView.fillForm(driver, "OFERTA 6");
		// Contamos el total de filas
		rows = (PO_View.checkElement(driver, "free", "//tbody/tr") != null)
				? PO_View.checkElement(driver, "free", "//tbody/tr").size()
				: 0;
		// Comprobamos que la lista est� vac�a
		assertEquals(1, rows);
		// Rellenamos el formulario
		PO_ListOffersView.fillForm(driver, "oFeRTa 6");
		// Contamos el total de filas
		rows = (PO_View.checkElement(driver, "free", "//tbody/tr") != null)
				? PO_View.checkElement(driver, "free", "//tbody/tr").size()
				: 0;
		// Comprobamos que la lista est� vac�a
		assertEquals(1, rows);
	}

	/**
	 * PR23. Sobre una b�squeda determinada, comprar una oferta que deja un saldo
	 * positivo en el contador del comprador. Comprobar que el contador se actualiza
	 * correctamente en la vista del comprador /
	 */
	@Test
	public void PR23() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/list')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillForm(driver, "Oferta 5");

		// Clicamos en el bot�n de comprar
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableOffers']/tbody/tr/td[4]/form/button");
		elements.get(0).click();
		// Recogemos la informaci�n del usuario
		elements = PO_View.checkElement(driver, "free", "//*[@id='authenticatedUser']");
		// Comprobamos que el resultado es el esperado
		assertEquals(elements.get(0).getText(), "susana@email.com - saldo: 50 �");
	}

	/**
	 * PR24. Sobre una b�squeda determinada (a elecci�n del desarrollador), comprar
	 * una oferta que deja un saldo 0 en el contador del comprador. Comprobar que el
	 * contador se actualiza correctamente en la vista del comprador
	 */
	@Test
	public void PR24() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/list')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillForm(driver, "Oferta 10");
		// Clicamos en el bot�n de comprar
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableOffers']/tbody/tr/td[4]/form/button");
		elements.get(0).click();
		// Recogemos la informaci�n del usuario
		elements = PO_View.checkElement(driver, "free", "//*[@id='authenticatedUser']");
		// Comprobamos que el resultado es el esperado
		assertEquals(elements.get(0).getText(), "susana@email.com - saldo: 0 �");
	}

	/**
	 * PR25. Sobre una b�squeda determinada (a elecci�n del desarrollador), intentar
	 * comprar una oferta que est� por encima de saldo disponible del comprador. Y
	 * comprobar que se muestra el mensaje de saldo no suficiente
	 */
	@Test
	public void PR25() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/list')]");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillForm(driver, "Oferta 15");
		// Clicamos en el bot�n de comprar
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableOffers']/tbody/tr/td[4]/form/button");
		elements.get(0).click();
		// Comprobamos el error
		assertNotNull(PO_SignupView.checkKey(driver, "No tienes suficiente saldo para comprar la oferta"));
	}

	/**
	 * PR26. Ir a la opci�n de ofertas compradas del usuario y mostrar la lista.
	 * Comprobar que aparecen las ofertas que deben aparecer
	 */
	@Test
	public void PR26() {
		// Iniciamos sesi�n
		PO_LoginView.login(driver, "domingo@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/list')]");
		elements.get(0).click();
		// Compramos 3 ofertas
		PO_ListOffersView.fillForm(driver, "Oferta 1");
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableOffers']/tbody/tr/td[4]/form/button");
		elements.get(0).click();
		PO_ListOffersView.fillForm(driver, "Oferta 2");
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableOffers']/tbody/tr/td[4]/form/button");
		elements.get(0).click();
		PO_ListOffersView.fillForm(driver, "Oferta 3");
		elements = PO_View.checkElement(driver, "free", "//*[@id='tableOffers']/tbody/tr/td[4]/form/button");
		elements.get(0).click();
		// Clicamos en la opci�n de menu de ofertas
		elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers-menu')]/a");
		elements.get(0).click();
		// Pinchamos en la opci�n de ver ofertas compradas
		elements = PO_View.checkElement(driver, "free", "//a[contains(@href, 'offers/buyed/list')]");
		elements.get(0).click();
		// Comprobamos que aparecen en el listado
		assertNotNull(PO_View.checkElement(driver, "text", "Oferta 1"));
		assertNotNull(PO_View.checkElement(driver, "text", "Oferta 2"));
		assertNotNull(PO_View.checkElement(driver, "text", "Oferta 3"));
	}

	/**
	 * PR30. Inicio de sesi�n con datos v�lidos
	 */
	@Test
	public void PR30() {
		// ir a la direcci�n del cliente
		driver.navigate().to(URL + "cliente.html?w=login");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, "admin@email.com", "admin");
		// Comprobamos que entramos en la secci�n privada
		assertNotNull(PO_View.checkElement(driver, "text", "Usuario autenticado con �xito"));
	}

	/**
	 * PR31. Inicio de sesi�n con datos inv�lidos (email existente, pero contrase�a
	 * incorrecta)
	 */
	@Test
	public void PR31() {
		// ir a la direcci�n del cliente
		driver.navigate().to(URL + "cliente.html?w=login");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, "susana@email.com", "654321");
		// Comprobamos el error
		assertNotNull(PO_View.checkElement(driver, "text", "Email o contrase�a incorrectos"));
	}

	/**
	 * PR32. Inicio de sesi�n con datos v�lidos (campo email o contrase�a vac�os)
	 */
	@Test
	public void PR32() {
		// ir a la direcci�n del cliente
		driver.navigate().to(URL + "cliente.html?w=login");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, "", "");
		// Comprobamos el error
		assertNotNull(PO_View.checkElement(driver, "text", "Debe rellenar el campo de email"));
		assertNotNull(PO_View.checkElement(driver, "text", "Debe rellenar el campo de contrase�a"));
	}

	/**
	 * PR33. Mostrar el listado de ofertas disponibles y comprobar que se muestran
	 * todas las que existen, menos las del usuario identificado
	 */
	@Test
	public void PR33() {
		// ir a la direcci�n del cliente
		driver.navigate().to(URL + "cliente.html?w=login");
		// Iniciamos sesi�n
		PO_LoginView.fillForm(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers')]/a");
		elements.get(0).click();
		// Contamos el n�mero de filas de ofertas y lo comparamos con el n�mero de
		// ofertas totales (exceptuando las del usuario autenticado)
		elements = PO_View.checkElement(driver, "free", "//tbody/tr");
		// Comparamos con el n�mero esperado de oferta
		assertEquals(12, elements.size());
	}

	/**
	 * PR34. Sobre una b�squeda determinada de ofertas (a elecci�n de
	 * desarrollador), enviar un mensaje a una oferta concreta. Se abrir�a dicha
	 * conversaci�n por primera vez. Comprobar que el mensaje aparece en el listado
	 * de mensajes
	 */
	@Test
	public void PR34() {
		// ir a la direcci�n del cliente
		driver.navigate().to(URL + "cliente.html?w=login");
		// Iniciamos sesi�n
		PO_LoginView.fillForm(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers')]/a");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillFormClient(driver, "Oferta 10");
		// Clicamos en el bot�n de abrir conversaci�n
		elements = PO_View.checkElement(driver, "free", "//*[@id='conversation-Oferta 10']");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_AddMessageView.fillForm(driver, "Hola");
		// Comprobamos que se ha enviado el mensaje
		assertNotNull(PO_SignupView.checkKey(driver, "Mensaje enviado con �xito"));
		// Comprobamos que el mensaje aparece en la lista
		assertNotNull(PO_SignupView.checkKey(driver, "Hola"));
	}

	/**
	 * PR35. Sobre el listado de conversaciones enviar un mensaje a una conversaci�n
	 * ya abierta. Comprobar que el mensaje aparece en el listado de mensajes
	 */
	@Test
	public void PR35() {
		// ir a la direcci�n del cliente
		driver.navigate().to(URL + "cliente.html?w=login");
		// Iniciamos sesi�n
		PO_LoginView.fillForm(driver, "susana@email.com", "123456");
		// Clicamos en la opci�n de menu de ofertas
		List<WebElement> elements = PO_View.checkElement(driver, "free", "//li[contains(@id,'offers')]/a");
		elements.get(0).click();
		// Rellenamos el formulario
		PO_ListOffersView.fillFormClient(driver, "Oferta 15");
		// Clicamos en el bot�n de abrir conversaci�n
		elements = PO_View.checkElement(driver, "free", "//*[@id='conversation-Oferta 15']");
		elements.get(0).click();
		// Comprobamos que se ha entrado en la opci�n de mensajer�a
		assertNotNull(PO_SignupView.checkKey(driver, "Nuevo mensaje"));
		// Comprobamos que los mensajes anteriores aparece en la lista
		assertNotNull(PO_SignupView.checkKey(driver, "Hola"));
		// Rellenamos el formulario
		PO_AddMessageView.fillForm(driver, "Estoy interesada en la oferta");
		// Comprobamos que se ha enviado el mensaje
		assertNotNull(PO_SignupView.checkKey(driver, "Mensaje enviado con �xito"));
		// Comprobamos que el mensaje aparece en la lista
		assertNotNull(PO_SignupView.checkKey(driver, "Estoy interesada en la oferta"));
	}
}