package tests.pageobjects;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import test.util.SeleniumUtils;

public class PO_View {

	protected static int timeout = 2;

	public static int getTimeout() {
		return timeout;
	}

	public static void setTimeout(int timeout) {
		PO_View.timeout = timeout;
	}

	/**
	 * Espera por la visibilidad de un texto correspondiente a la propiedad key en
	 * el idioma locale en la vista actualmente cargandose en driver..
	 * 
	 * @param driver: apuntando al navegador abierto actualmente.
	 * @param text:    texto a comparar
	 * @return Se retornar� la lista de elementos resultantes de la b�squeda.
	 */
	static public List<WebElement> checkKey(WebDriver driver, String text) {
		List<WebElement> elementos = SeleniumUtils.EsperaCargaPagina(driver, "text", text, getTimeout());
		return elementos;
	}

	/**
	 * Espera por la visibilidad de un elemento/s en la vista actualmente cargandose
	 * en driver..
	 * 
	 * @param driver: apuntando al navegador abierto actualmente.
	 * @param type:
	 * @param text:
	 * @return Se retornar� la lista de elementos resultantes de la b�squeda.
	 */
	static public List<WebElement> checkElement(WebDriver driver, String type, String text) {
		List<WebElement> elementos = new LinkedList<WebElement>();
		try {
			elementos = SeleniumUtils.EsperaCargaPagina(driver, type, text, getTimeout());
		} catch (TimeoutException e) {

			return null;
		}
		return elementos;
	}

	/**
	 * Espera por la no visibilidad de un texto en la vista actualmente cargandose
	 * en driver..
	 * 
	 * @param driver: apuntando al navegador abierto actualmente.
	 * @param type:
	 * @param text:
	 * @return Aborta si el texto est� presente en la p�gina.
	 */
	static public boolean checkNotElement(WebDriver driver, String text) {
		return SeleniumUtils.EsperaCargaPaginaNoTexto(driver, text, getTimeout());
	}
}
