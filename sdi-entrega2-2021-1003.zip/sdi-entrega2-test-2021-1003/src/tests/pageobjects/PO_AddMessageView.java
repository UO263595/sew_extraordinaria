package tests.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PO_AddMessageView extends PO_NavView {
	/**
	 * Env�a un mensaje
	 * @param driver
	 * @param messagep - texto del mensaje
	 */
	static public void fillForm(WebDriver driver, String messagep) {
		WebElement message = driver.findElement(By.name("textMessage"));
		message.click();
		message.clear();
		message.sendKeys(messagep);
		// Pulsar el bot�n de enviar
		By boton = By.className("btn");
		driver.findElement(boton).click();
	}
}
