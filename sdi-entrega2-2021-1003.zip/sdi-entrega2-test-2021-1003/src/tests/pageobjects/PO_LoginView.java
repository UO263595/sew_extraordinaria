package tests.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PO_LoginView extends PO_NavView {
	
	/**
	 * Loguea a un usuario
	 * @param driver
	 * @param usernamep - email del usuario
	 * @param passwordp - contrase�a del usuario
	 */
	static public void fillForm(WebDriver driver, String usernamep, String passwordp) {
		WebElement username = driver.findElement(By.name("email"));
		username.click();
		username.clear();
		username.sendKeys(usernamep);
		WebElement password = driver.findElement(By.name("password"));
		password.click();
		password.clear();
		password.sendKeys(passwordp);
		// Pulsar el bot�n de enviar
		By boton = By.className("btn");
		driver.findElement(boton).click();
	}

	/**
	 * Loguea a un usuario y si ya hay uno logueado anteriormente, este se desloguea
	 * @param driver
	 * @param usernamep - email del usuario
	 * @param passwordp - contrase�a del usuario
	 */
	static public void login(WebDriver driver, String usernamep, String passwordp) {
		// Si un usuario est� autenticado se desconecta
		// Pulsamos el bot�n de desconexi�n
		if (PO_View.checkElement(driver, "free", "//*[@id='authenticatedUser']") != null)
			PO_NavView.clickOption(driver, "disconect", "class", "btn btn-primary");

		// Vamos al formulario de registro
		PO_NavView.clickOption(driver, "login", "class", "btn btn-primary");
		// Rellenamos el formulario
		PO_LoginView.fillForm(driver, usernamep, passwordp);
		// Comprobamos que entramos en la secci�n privada
		PO_View.checkElement(driver, "free", "//a[contains(@id,'authenticatedUsername')]");
	}
}
