package tests.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PO_ListOffersView extends PO_NavView {
	
	/**
	 * Realiza una b�squeda de ofertas
	 * @param driver
	 * @param searchp - par�metro de la b�squeda
	 */
	static public void fillForm(WebDriver driver, String searchp) {
		WebElement search = driver.findElement(By.id("search"));
		search.click();
		search.clear();
		search.sendKeys(searchp);
		// Pulsar el bot�n de enviar
		By boton = By.className("btn");
		driver.findElement(boton).click();
	}
	
	/**
	 * Realiza una b�squeda de ofertas (cliente ligero)
	 * @param driver
	 * @param searchp - par�metro de la b�squeda
	 */
	static public void fillFormClient(WebDriver driver, String searchp) {
		WebElement search = driver.findElement(By.id("search"));
		search.click();
		search.clear();
		search.sendKeys(searchp);
	}
}
