package tests.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PO_SignupView extends PO_NavView {
	
	/**
	 * Registra a un nuevo usuario
	 * @param driver
	 * @param emailp - email del usuario
	 * @param namep - nombre del usuario
	 * @param surnamep - apellidos del usuario
	 * @param passwordp - contrase�a del usuario
	 * @param repeatpasswordp - repetici�n de la contrase�a
	 */
	static public void fillForm(WebDriver driver, String emailp, String namep, String surnamep, String passwordp,
			String repeatpasswordp) {
		WebElement email = driver.findElement(By.name("email"));
		email.click();
		email.clear();
		email.sendKeys(emailp);
		WebElement name = driver.findElement(By.name("name"));
		name.click();
		name.clear();
		name.sendKeys(namep);
		WebElement surname = driver.findElement(By.name("surname"));
		surname.click();
		surname.clear();
		surname.sendKeys(surnamep);
		WebElement password = driver.findElement(By.name("password"));
		password.click();
		password.clear();
		password.sendKeys(passwordp);
		WebElement repeatPassword = driver.findElement(By.name("repeatPassword"));
		repeatPassword.click();
		repeatPassword.clear();
		repeatPassword.sendKeys(repeatpasswordp);
		// Pulsar el bot�n de alta
		By boton = By.className("btn");
		driver.findElement(boton).click();
	}
}
