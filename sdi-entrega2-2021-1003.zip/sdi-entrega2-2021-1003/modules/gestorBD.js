module.exports = {
    /**
     * Inicialización del gestor de la base de datos
     */
    mongo: null,
    app: null,
    init: function (app, mongo) {
        this.mongo = mongo;
        this.app = app;
    },

    /**
     * Inserta un nuevo usuario en la base de datos
     * @param user - el usuario a insertar
     * @param funcionCallback - resultado de la inserción
     */
    addUser : function(user, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('users');
                collection.insert(user, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result.ops[0]._id);
                    }
                    db.close();
                });
            }
        });
    },

    /**
     * Recupera los usuarios de la base de datos
     * @param criterio - datos de los usuarios que se quieren recuperar
     * @param funcionCallback - resultado de la búsqueda
     */
    getUsers : function(criterio, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('users');
                collection.find(criterio).toArray(function(err, users) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(users);
                    }
                    db.close();
                });
            }
        });
    },

    /**
     * Elimina un usuario de la base de datos
     * @param user - el usuario a eliminar
     * @param funcionCallback - resultado de la eliminación
     */
    deleteUser : function(user, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('users');
                collection.deleteOne(user)
                    .then(() => funcionCallback(user))
                    .catch(() => funcionCallback(null));
            }
            db.close();
        });
    },

    /**
     * Inserta una nueva oferta en la base de datos
     * @param offer - la oferta a insertar
     * @param funcionCallback - resultado de la inserción
     */
    addOffer : function(offer, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('offers');
                collection.insert(offer, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result.ops[0]._id);
                    }
                    db.close();
                });
            }
        });
    },

    /**
     * Recupera las ofertas de la base de datos
     * @param criterio - datos de las ofertas que se quieren recuperar
     * @param funcionCallback - resultado de la búsqueda
     */
    getOffers : function(criterio, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function (err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('offers');
                collection.find(criterio).toArray(function(err, offers) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(offers);
                    }
                    db.close();
                });
            }
        });
    },

    /**
     * Recupera las ofertas de la base de datos (con paginación)
     * @param criterio - datos de las ofertas que se quieren recuperar
     * @param pg - paginación
     * @param funcionCallback - resultado de la búsqueda
     */
    getOffersPg : function(criterio, pg, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('offers');
                collection.find(criterio).count(function (err, count) {
                    collection.find(criterio).skip((pg - 1) * 5).limit(5).toArray(function (err, offers) {
                            if (err) {
                                funcionCallback(null);
                            } else {
                                funcionCallback(offers, count);
                            }
                            db.close();
                        });
                });
            }
        });
    },

    /**
     * Elimina una oferta de la base de datos
     * @param offer - la oferta a eliminar
     * @param funcionCallback - resultado de la eliminación
     */
    deleteOffer : function(offer, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('offers');
                collection.deleteOne(offer)
                    .then(() => funcionCallback(offer))
                    .catch(() => funcionCallback(null));
            }
            db.close();
        });
    },

    /**
     * Actualiza una oferta de la base de datos
     * @param criterio - datos de la oferta que se quiere modificar
     * @param offer - la oferta a modificar
     * @param funcionCallback - resultado de la actualización
     */
    updateOffer : function(criterio, offer, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('offers');
                collection.update(criterio, {$set: offer}, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result);
                    }
                    db.close();
                });
            }
        });
    },

    /**
     * Actualiza un usuario de la base de datos
     * @param criterio - datos del usuario que se quiere modificar
     * @param user - el usuario a modificar
     * @param funcionCallback - resultado de la actualización
     */
    updateUser : function(criterio, user, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('users');
                collection.update(criterio, {$set: user}, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result);
                    }
                    db.close();
                });
            }
        });
    },

    /**
     * Inserta un mensaje en la base de datos
     * @param message - el mensaje a insertar
     * @param funcionCallback - resultado de la inserción
     */
    addMessage : function(message, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('messages');
                collection.insert(message, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result.ops[0]._id);
                    }
                    db.close();
                });
            }
        });
    },

    /**
     * Recupera los mensajes de la base de datos
     * @param criterio - datos de los mensajes que se quieren recuperar
     * @param funcionCallback - resultado de la búsqueda
     */
    getMessages : function(criterio, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function (err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('messages');
                collection.find(criterio).toArray(function(err, messages) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(messages);
                    }
                    db.close();
                });
            }
        });
    },

    /**
     * Elimina un mensaje de la base de datos
     * @param message - el mensaje a eliminar
     * @param funcionCallback - resultado de la eliminación
     */
    deleteMessage : function(message, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('messages');
                collection.deleteOne(message)
                    .then(() => funcionCallback(message))
                    .catch(() => funcionCallback(null));
            }
            db.close();
        });
    },

    /**
     * Actualiza un mensaje con los atributos enviados por parámetro
     * @param criterio - datos del mensaje que se quiere actualizar
     * @param message - los nuevos atributos del mensaje
     * @param funcionCallback - resultado de la actualización
     */
    updateMessage : function(criterio, message, funcionCallback) {
        this.mongo.MongoClient.connect(this.app.get('db'), function(err, db) {
            if (err) {
                funcionCallback(null);
            } else {
                let collection = db.collection('messages');
                collection.update(criterio, {$set: message}, function(err, result) {
                    if (err) {
                        funcionCallback(null);
                    } else {
                        funcionCallback(result);
                    }
                    db.close();
                });
            }
        });
    }
};