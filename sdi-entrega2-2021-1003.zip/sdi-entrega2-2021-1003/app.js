// Módulos
let express = require('express');
let app = express();
app.use(express.static('public'));
let mongo = require('mongodb');
let swig = require('swig');
let bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
let gestorBD = require("./modules/gestorBD.js");
gestorBD.init(app, mongo);
let expressSession = require('express-session');
app.use(expressSession({secret: 'abcdefg', resave: true, saveUninitialized: true}));
let crypto = require('crypto');
let jwt = require('jsonwebtoken');
app.set('jwt',jwt);
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Credentials", "true");
    res.header("Access-Control-Allow-Methods", "POST, GET, DELETE, UPDATE, PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, token");
    // Debemos especificar todas las headers que se aceptan. Content-Type , token
    next();
});

// logger
const log4js = require('log4js');
// Logger configuration
log4js.configure({
    appenders: { fileAppender: { type: 'file', filename: './logs/registro.log' } },
    categories: { default: { appenders: ['fileAppender'], level: 'info' } }
});
// Create the logger
const logger = log4js.getLogger();
logger.level = 'info';

// Routers
/**
 * Router que sólo permite eliminar una oferta si se es el vendedor y la oferta no está vendida con anterioridad
 * @type {Router}
 */
let routerDeleteOffers = express.Router();
routerDeleteOffers.use(function(req, res, next) {
    let path = require('path');
    let idOffer = path.basename(req.originalUrl);
    gestorBD.getOffers({"_id": mongo.ObjectID(idOffer)}, function (offers) {
            if(req.session.user && offers[0].vendor===req.session.user.email && !offers[0].sold) {
                // dejamos correr la petición
                next();
            } else if (req.session.user) {
                logger.error(req.session.user.email+" ha intentado eliminar la oferta "+idOffer);
                req.session.errors=[{message: "Error al eliminar la oferta", messageType: "alert-danger"}];
                res.redirect("/home");
            } else {
                logger.error("usuario no autenticado ha intentado eliminar la oferta "+idOffer);
                req.session.errors=[{message: "Debes iniciar sesión para eliminar una oferta", messageType: "alert-danger"}];
                res.redirect("/login");
            }
        })
});
// aplicar router
app.use("/offers/delete/", routerDeleteOffers);

/**
 * Router que sólo permite comprar una oferta si no se es el vendedor y la oferta no está vendida con anterioridad
 * @type {Router}
 */
let routerBuyOffers = express.Router();
routerBuyOffers.use(function(req, res, next) {
    let path = require('path');
    let idOffer = path.basename(req.originalUrl);
    gestorBD.getOffers({"_id": mongo.ObjectID(idOffer)}, function (offers) {
        if(req.session.user && offers[0].vendor!==req.session.user.email && !offers[0].sold) {
            // dejamos correr la petición
            next();
        } else if (req.session.user) {
            logger.error("usuario no autenticado ha intentado comprar la oferta "+idOffer);
            req.session.errors=[{message: "Error al comprar la oferta", messageType: "alert-danger"}];
            res.redirect("/home");
        } else {
            logger.error(" ha intentado comprar la oferta "+idOffer);
            req.session.errors=[{message: "Debes iniciar sesión para comprar una oferta", messageType: "alert-danger"}];
            res.redirect("/login");
        }
    })
});
// aplicar router
app.use("/offers/buy/", routerBuyOffers);

/**
 * Router que sólo permite el acceso a las URLs si el usuario está autenticado
 * @type {Router}
 */
let routerSession = express.Router();
routerSession.use(function(req, res, next) {
    if (req.session.user) {
        // dejamos correr la petición
        next();
    } else {
        logger.error("usuario no autenticado ha intentado acceder a zonas privadas de la web");
        res.redirect("/login");
    }
});
// aplicar router
app.use("/home", routerSession);
app.use("/disconect", routerSession);
app.use("/users/*", routerSession);
app.use("/offers/*", routerSession);

/**
 * Router que sólo permite el acceso a las URLs si el usuario no está autenticado
 * @type {Router}node
 */
let routerNotSession = express.Router();
routerNotSession.use(function(req, res, next) {
    if (!req.session.user) {
        // dejamos correr la petición
        next();
    } else {
        logger.error(req.session.user.email+" ha intentado acceder a partes no accesibles a usuarios autenticados de la web");
        res.redirect("/home");
    }
});
// aplicar routerSession
app.use("/login", routerNotSession);
app.use("/signup", routerNotSession);

/**
 * Router que sólo permite el acceso a las URLs si el usuario está autenticado y es administrador
 * @type {Router}
 */
let routerAdmin = express.Router();
routerAdmin.use(function(req, res, next) {
    if (req.session.user) {
        if (req.session.user.role === "admin") {
            // dejamos correr la petición
            next();
        } else {
            logger.error(req.session.user.email+" ha intentado acceder a zonas destinadas a usuarios administradores");
            res.redirect("/home");
        }
    } else {
        logger.error("usuario no autenticado ha intentado acceder a zonas destinadas a usuarios administradores");
        res.redirect("/login");
    }
});
// aplicar router
app.use("/users/*", routerAdmin);
app.use("/deleteBD", routerAdmin);
app.use("/initBD", routerAdmin);

/**
 * Router que gestiona el Token
 * @type {Router}
 */
let routerToken = express.Router();
routerToken.use(function(req, res, next) {
    // obtener el token, vía headers (opcionalmente GET y/o POST).
    let token = req.headers['token'] || req.body.token || req.query.token;
    if (token != null) {
        // verificar el token
        jwt.verify(token, 'secreto', function(err, infoToken) {
            if (err || (Date.now()/1000 - infoToken.tiempo) > 240) {
                res.status(403); // Forbidden
                res.json({
                    acceso : false,
                    error: 'Token invalido o caducado'
                });
            } else {
                // dejamos correr la petición
                res.user = infoToken.usuario;
                next();
            }
        });
    } else {
        res.status(403); // Forbidden
        res.json({
            acceso : false,
            message: 'No hay Token'
        });
    }
});
// aplicar router
app.use('/api/offers/*', routerToken);
app.use('/api/messages/*', routerToken);

// Variables
app.set('port',8081);
app.set('db','mongodb://admin:sdi@mywallapop-shard-00-00.1vzgh.mongodb.net:27017,mywallapop-shard-00-01.1vzgh.mongodb.net:27017,mywallapop-shard-00-02.1vzgh.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-res46p-shard-0&authSource=admin&retryWrites=true&w=majority');
app.set('clave','abcdefg');
app.set('crypto',crypto);

// Rutas/controladores por lógica
require("./routes/rhome.js")(app, swig, logger);
require("./routes/radmin.js")(app, gestorBD, logger);
require("./routes/rusers.js")(app, swig, gestorBD, logger);
require("./routes/roffers.js")(app, swig, gestorBD, logger);
require("./routes/rapiusers.js")(app, gestorBD, logger);
require("./routes/rapioffers.js")(app, gestorBD, logger);
require("./routes/rapimessages.js")(app, gestorBD, logger);

// Lanzar el servidor
app.listen(app.get('port'), function() {
    console.log("Servidor activo");
    logger.info("Servidor activo");
});