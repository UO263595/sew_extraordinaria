window.history.pushState("", "", "/cliente.html?w=offers");

/**
 * Carga las ofertas en la vista correspondiente
 */
function loadOffers() {
    clearInterval(uploadMessages);
    $.ajax({
        url: URLbase + "/offers/list",
        type: "GET",
        data: { },
        dataType: 'json',
        headers: { "token": token },
        success: function(respuesta) {
            const divInformation = document.getElementById("information");
            while (divInformation.firstChild) {
                divInformation.removeChild(divInformation.lastChild);
            }
            offers = respuesta;
            updateTable(offers);
        },
        error : function () {
            const divInformation = document.getElementById("information");
            while (divInformation.firstChild) {
                divInformation.removeChild(divInformation.lastChild);
            }
            $( "#contenedor-principal" ).load("widget-login.html");
        }
    });
}

/**
 * Carga la lista de ofertas propias en la vista correspondiente
 */
function loadOwnOffers() {
    $.ajax({
        url: URLbase + "/offers/own/list",
        type: "GET",
        data: { },
        dataType: 'json',
        headers: { "token": token },
        success: function(respuesta) {
            const divInformation = document.getElementById("information");
            while (divInformation.firstChild) {
                divInformation.removeChild(divInformation.lastChild);
            }
            offers = respuesta;
            updateOwnTable(offers);
        },
        error : function () {
            const divInformation = document.getElementById("information");
            while (divInformation.firstChild) {
                divInformation.removeChild(divInformation.lastChild);
            }
            $( "#contenedor-principal" ).load("widget-login.html");
        }
    });
}

/**
 * Actualiza la tabla de ofertas
 * @param offers - las ofertas a introducir en la tabla
 */
function updateTable(offers) {
    $( "#tablaCabecera" ).empty(); // vaciar la tabla
    $( "#tablaCabecera" ).append(
        "<tr>" +
        "<th>Título</th>" +
        "<th>Detalle</th>" +
        "<th>Precio</th>" +
        "<th>Email del vendedor</th>" +
        "<th class=\"col-md-1\"></th>" +
        "</tr>" );
    $( "#tablaCuerpo" ).empty(); // vaciar la tabla
    for (let i = 0; i < offers.length; i++) {
        $( "#tablaCuerpo" ).append(
            "<tr id="+offers[i]._id+">" +
            "<td>"+offers[i].title+"</td>" +
            "<td>"+offers[i].detail+"</td>" +
            "<td>"+offers[i].price+"</td>" +
            "<td>"+offers[i].vendor+"</td>" +
            "<td><a id='conversation-"+offers[i].title+"' onclick=conversation('"+offers[i]._id+"')>abrir conversación</a><br></td>" +
            "</tr>" );
    }
}

/**
 * Actualiza la tabla de ofertas propias
 * @param offers - las ofertas a introducir en la tabla
 */
function updateOwnTable(offers) {
    $( "#tablaCabecera" ).empty(); // vaciar la tabla
    $( "#tablaCabecera" ).append(
        "<tr>" +
        "<th>Título</th>" +
        "<th>Detalle</th>" +
        "<th>Precio</th>" +
        "</tr>" );
    $( "#tablaCuerpo" ).empty(); // vaciar la tabla
    for (let i = 0; i < offers.length; i++) {
        $( "#tablaCuerpo" ).append(
            "<tr id="+offers[i]._id+">" +
            "<td>"+offers[i].title+"</td>" +
            "<td>"+offers[i].detail+"</td>" +
            "<td>"+offers[i].price+"</td>" +
            "</tr>" );
    }
}

/**
 * Carga los mensajes de una oferta en la vista correspondiente
 * @param _id - id de la oferta a la que pertenece la conversación
 */
function conversation(_id) {
    idOffer = _id;
    $( "#contenedor-principal" ).load( "widget-messages.html");
}

// se cargan las ofertas propias o el resto de ofertas, dependiendo de la opción seleccionada
if (ownOffers) {
    loadOwnOffers();
} else {
    loadOffers();
}

/**
 * Cuando se actualiza el input de búsqueda se filtran las ofertas correspondientes
 */
$('#search').on('input',function() {
    let filteredOffers = [];
    let filterTitle = $("#search").val();

    for (i = 0; i < offers.length; i++) {
        if (offers[i].title.indexOf(filterTitle) !== -1) {
            filteredOffers.push(offers[i]);
        }
    }
    updateTable(filteredOffers);
});