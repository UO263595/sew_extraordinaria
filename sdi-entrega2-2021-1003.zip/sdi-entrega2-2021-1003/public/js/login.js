window.history.pushState("", "", "/cliente.html?w=login");

/**
 * Autentica a un usuario
 * Añade las opciones de usuario autenticado en el panel de navegación
 */
$("#boton-login").click(function () {
    $.ajax({
        url: URLbase + "/login",
        type: "POST",
        data: {
            email : $("#email").val(),
            password : $("#password").val()
        },
        dataType: 'json',
        success: function (respuesta) {
            //console.log(respuesta.token);
            const divMenu = document.getElementById("barra-menu");
            while (divMenu.firstChild) {
                divMenu.removeChild(divMenu.lastChild);
            }
            const divInformation = document.getElementById("information");
            while (divInformation.firstChild) {
                divInformation.removeChild(divInformation.lastChild);
            }
            token = respuesta.token;
            Cookies.set('token', respuesta.token);
            document.getElementById("logo").src="/img/student-48.png";
            $("#information").prepend("<div name='info' class='alert alert-info'>Usuario autenticado con éxito</div>");
            $("#barra-menu").prepend("<li id='own-offers'><a onclick=widgetOwnOffers()>Ofertas propias</a></li>");
            $("#barra-menu").prepend("<li id='offers'><a onclick=widgetOffers()>Ofertas</a></li>");
        },
        error: function () {
            Cookies.remove('token');
            const divInformation = document.getElementById("information");
            console.log(divInformation);
            while (divInformation.firstChild) {
                divInformation.removeChild(divInformation.lastChild);
            }

            if ($("#password").val()==="")
                $("#information").prepend("<div name='error' class='alert alert-danger'>Debe rellenar el campo de contraseña</div>");
            if ($("#email").val()==="")
                $("#information").prepend("<div name='error' class='alert alert-danger'>Debe rellenar el campo de email</div>");
            $("#information").prepend("<div name='error' class='alert alert-danger'>Email o contraseña incorrectos</div>");
        }
    });
});