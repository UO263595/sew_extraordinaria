window.history.pushState("", "", "/cliente.html?w=messages");

/**
 * Carga los mensajes en la vista correspondiente
 */
function loadMessages() {
    $.ajax({
        url: URLbase + "/messages/"+idOffer,
        type: "GET",
        data: { },
        dataType: 'json',
        headers: { "token": token },
        success: function(respuesta) {
            let messages = respuesta;
            updateTable(messages);
        },
        error : function () {
            $( "#contenedor-principal" ).load("widget-login.html");
        }
    });
}

/**
 * Actualiza la tabla de mensajes
 * @param messages - los mensajes a introducir en la tabla
 */
function updateTable(messages) {
    $( "#tablaCuerpo" ).empty(); // vaciar la tabla
    for (let i = 0; i < messages.length; i++) {
        $( "#tablaCuerpo" ).append(
            "<tr id="+messages[i]._id+">" +
            "<td>"+messages[i].author+"</td>" +
            "<td>"+messages[i].text+"</td>" +
            "</tr>" );
    }
}

/**
 * Envía un mensaje
 */
function sendMessage() {
    $.ajax({
        url: URLbase + "/messages/send/"+idOffer,
        type: "POST",
        data: {
            text : $("#textMessage").val()
        },
        dataType: 'json',
        headers: { "token": token },
        success: function () {
            const divInformation = document.getElementById("information");
            while (divInformation.firstChild) {
                divInformation.removeChild(divInformation.lastChild);
            }
            $("#information").prepend("<div name='info' class='alert alert-info'>Mensaje enviado con éxito</div>");
        },
        error: function () {
            const divInformation = document.getElementById("information");
            while (divInformation.firstChild) {
                divInformation.removeChild(divInformation.lastChild);
            }
            if ($("#textMessage").val()==="")
                $("#information").prepend("<div name='error' class='alert alert-danger'>Debe rellenar el texto del mensaje</div>");
            $("#information").prepend("<div name='error' class='alert alert-danger'>Ha ocurrido un error</div>");
        }
    });
}

// llamada a la función que carga los mensajes
loadMessages();
// establece un intervalo de tiempo para la actualización de la tabla de mensajes
uploadMessages = setInterval(function() {loadMessages();}, 500);