module.exports = function(app, swig, gestorBD, logger) {
    /**
     * Muestra la vista de registrarse
     */
    app.get("/signup", function(req, res) {
        let respuesta = swig.renderFile('views/users/signup.html', {errors: req.session.errors});
        req.session.errors=null;
        res.send(respuesta);
    });

    /**
     * Inserta un nuevo usuario en la base de datos
     * Si no hay errores se envía a la vista de identificarse con un mensaje de información
     * Si hay errores se muestran en un mensaje en la vista de registrarse
     */
    app.post('/signup', function(req, res) {
        // Control de errores
        req.session.errors=[];

        let criterio = {email : req.body.email};
        gestorBD.getUsers(criterio, function(users) {
            // error de email repetido
            if (users!=null && users.length!==0)
                req.session.errors.push({message : "El email está repetido en la base de datos", messageType : "alert-danger"});

            // errores del email
            let regex = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
            if (req.body.email.length===0) {
                req.session.errors.push({message : "Debe rellenar el campo de email", messageType : "alert-danger"});
            }
            else if (!regex.test(req.body.email) || req.body.email.length>25) {
                req.session.errors.push({message : "El email tiene un formato inválido", messageType : "alert-danger"});
            }
            if (req.body.email.length<5 || req.body.email.length>25) {
                req.session.errors.push({message : "El email debe contener entre 5 y 25 caracteres", messageType : "alert-danger"});
            }
            // errores del nombre
            if (req.body.name.length===0) {
                req.session.errors.push({message : "Debe rellenar el campo de nombre", messageType : "alert-danger"});
            }
            if (req.body.name.length<3 || req.body.name.length>25) {
                req.session.errors.push({message : "El nombre debe contener entre 3 y 25 caracteres", messageType : "alert-danger"});
            }
            // errores de los apellidos
            if (req.body.surname.length===0) {
                req.session.errors.push({message : "Debe rellenar el campo de apellidos", messageType : "alert-danger"});
            }
            if (req.body.surname.length<3 || req.body.surname.length>25) {
                req.session.errors.push({message : "Los apellidos deben contener entre 3 y 25 caracteres", messageType : "alert-danger"});
            }
            // errores de la contraseña
            if (req.body.password.length===0) {
                req.session.errors.push({message : "Debe rellenar el campo de contraseña", messageType : "alert-danger"});
            }
            if (req.body.password.length<3 || req.body.password.length>25) {
                req.session.errors.push({message : "La contraseña debe contener entre 3 y 25 caracteres", messageType : "alert-danger"});
            }
            // errores de repetición de la contraseña
            if (req.body.password!==req.body.repeatPassword) {
                req.session.errors.push({message : "La repetición de la contraseña es incorrecta", messageType : "alert-danger"});
            }

            // si hay errores se envían los mensajes a la vista
            if (req.session.errors.length>0) {
                res.redirect("/signup");
            } else {
                // se crea el usuario
                let seguro = app.get("crypto").createHmac('sha256', app.get('clave')).update(req.body.password).digest('hex');
                let user = {
                    email: req.body.email,
                    name: req.body.name,
                    surname: req.body.surname,
                    password : seguro,
                    moneyAccount: 100.0,
                    role: "standard"
                }

                // se inserta el usuario en la base de datos
                gestorBD.addUser(user, function(id) {
                    if (id == null) {
                        req.session.errors.push({message: "Ha ocurrido un error al registrar el usuario", messageType: "alert-danger"});
                        res.redirect("/signup");
                    } else {
                        req.session.information = [{message: "Nuevo usuario registrado", messageType: "alert-info"}];
                        req.session.user=user;
                        logger.info("se ha registrado el usuario: "+req.session.user.email);
                        res.redirect("/offers/list");
                    }
                });
            }
        });
    });

    /**
     * Muestra la vista de identificarse
     */
    app.get("/login", function(req, res) {
        let respuesta = swig.renderFile('views/users/login.html', {errors: req.session.errors});
        req.session.errors=null;
        res.send(respuesta);
    });

    /**
     * Inicia la sesión de un usuario
     * Si el usuario es administrador redirige a la vista de lista de usuarios
     * En caso contrario, redirige a la vista de ofertas disponibles
     */
    app.post("/login", function(req, res) {
        // Control de errores
        req.session.errors=[];

        if (req.body.email.length===0) {
            req.session.errors.push({message : "Debe rellenar el campo de email", messageType : "alert-danger"});
        }
        if (req.body.password.length===0) {
            req.session.errors.push({message : "Debe rellenar el campo de contraseña", messageType : "alert-danger"});
        }
        let seguro = app.get("crypto").createHmac('sha256', app.get('clave')).update(req.body.password).digest('hex');
        let criterio = {email: req.body.email, password: seguro};
        // buscar el usuario en la base de datos
        gestorBD.getUsers(criterio, function(users) {
            if (users==null || users.length===0) {
                req.session.user=null;
                req.session.errors.push({message: "Email o contraseña incorrectos", messageType: "alert-danger"});
                res.redirect("/login");
            } else {
                req.session.user=users[0];
                logger.info(req.session.user.email+" se ha logueado");
                if (users[0].role==="admin")
                    res.redirect("/users/list");
                else
                    res.redirect("/offers/list");
            }
        });
    });

    /**
     * Finaliza la sesión de un usuario
     * Redirige a la vista de identificarse
     */
    app.get('/disconect', function (req, res) {
        logger.info(req.session.user.email+" se ha desconectado");
        req.session.user=null;
        res.redirect("/login");
    });

    /**
     * Muestra la vista de listado de usuarios (excluyendo a los administradores)
     * Sólo disponible para usuarios administradores
     */
    app.get("/users/list", function(req, res) {
        // se excluyen a los usuarios con role "admin"
        let criterio={role: {$ne:"admin"}};
        // buscar los usuarios de la base de datos
        gestorBD.getUsers(criterio,function(users) {
            if (users==null) {
                req.session.errors=[{message: "Error al recuperar los usuarios", messageType: "alert-danger"}];
                res.redirect("/home");
            } else {
                let respuesta = swig.renderFile('views/users/list.html', {
                    users: users, errors: req.session.errors, information: req.session.information, session: req.session.user
                });
                req.session.information=null;
                req.session.errors=null;
                res.send(respuesta);
            }
        });
    });

    /**
     * Elimina los usuarios seleccionados de la base de datos
     */
    app.post("/users/delete", function(req, res) {
        for (let element in req.body.usersToDelete) {
            let criterioUser = {email: req.body.usersToDelete[element], role: {$ne:"admin"}};
            // Control de errores
            req.session.errors=[];
            // Control de información
            req.session.information=[];
            gestorBD.deleteUser(criterioUser, function(user) {
                if (user==null) {
                    req.session.errors.push({message: "Error al eliminar el usuario "+req.body.usersToDelete[element], messageType: "alert-danger"});
                    res.redirect("/users/list");
                }
                else {
                    let criterioOffer={ $or: [{vendor: user.email}, {buyer: user.email}]};
                    // buscar las ofertas de la base de datos
                    gestorBD.getOffers(criterioOffer,function(offers) {
                        if (offers!=null) {
                            for (let elementOffer in offers) {
                                // borrar la oferta de la base de datos
                                gestorBD.deleteOffer({_id: offers[elementOffer]._id}, function(offer) {
                                    if (offer==null) {
                                        req.session.errors.push({message: "Error al eliminar la oferta "+offers[elementOffer].title, messageType: "alert-danger"});
                                    }
                                });
                                // buscar los mensajes de la base de datos
                                gestorBD.getMessages({idOffer: offers[elementOffer]._id},function(messages) {
                                    if (messages!=null) {
                                        for (let elementMessage in messages) {
                                            // borrar el mensaje de la base de datos
                                            gestorBD.deleteMessage({_id: messages[elementMessage]._id}, function(message) {
                                                if (message==null) {
                                                    req.session.errors.push({message: "Error al eliminar el mensaje "+messages[elementMessage].title, messageType: "alert-danger"});
                                                }
                                            });

                                        }
                                    }
                                });
                            }
                        }
                    });
                    logger.info(req.session.user.email+" ha eliminado el usuario: "+req.body.usersToDelete[element].toString());
                    let text="Usuario "+req.body.usersToDelete[element].toString()+" eliminado";
                    req.session.information.push({message: text, messageType: "alert-info"});
                }
            });
        }
        res.redirect("/users/list");
    });
};