module.exports = function(app, gestorBD, logger) {

    /**
     * Envía un mensaje a una oferta
     * La oferta no puede estar vendida
     */
    app.post("/api/messages/send/:idOffer", function(req, res) {
        // Validar texto
        if (req.body.text===null) {
            res.status(400);
            res.json({
                error : "Se debe escribir un mensaje"
            });
            return;
        }
        if (req.body.text.length<3 || req.body.text.length>50) {
            res.status(400);
            res.json({
                error : "La longitud del mensaje debe ser de entre 3 y 50 caracteres"
            });
            return;
        }

        // Obtener los datos de la oferta
        let criterio = {_id: gestorBD.mongo.ObjectID(req.params.idOffer), vendor: {$ne: res.user}, sold: false};
        // buscar la oferta en la base de datos
        gestorBD.getOffers(criterio, function(offers) {
            if (offers==null || offers.length===0) {
                res.status(500);
                res.json({
                    error : "Ha ocurrido un error al recuperar la oferta"
                });
            } else {
                let message = {
                    author : res.user,
                    vendor : offers[0].vendor,
                    idOffer : gestorBD.mongo.ObjectID(req.params.idOffer),
                    text : req.body.text,
                    date : new Date(Date.now()).toDateString(),
                    read : false
                };

                // se inserta el mensaje en la base de datos
                gestorBD.addMessage(message, function(id) {
                    if (id == null) {
                        res.status(500);
                        res.json({
                            error : "Ha ocurrido un error al enviar el mensaje"
                        });
                    } else {
                        logger.info(res.user+" enviado el mensaje "+id);
                        res.status(200);
                        res.json({
                            info : "El mensaje se ha enviado con éxito"
                        });
                    }
                });
            }
        });
    });

    /**
     * Muestra los mensajes existentes en la base de datos vinculadas al usuario autenticado
     * El usuario debe estar autenticado
     */
    app.get("/api/messages/list", function(req, res) {
        let criterio = { $or: [{author: res.user}, {vendor: res.user}]};
        gestorBD.getMessages( criterio, function(messages) {
            if (messages == null) {
                res.status(500);
                res.json({
                    error : "Se ha producido un error"
                });
            } else {
                res.status(200);
                res.send( JSON.stringify(messages) );
            }
        });
    });

    /**
     * Muestra el listado de mensajes de una conversación
     */
    app.get("/api/messages/:idOffer", function(req, res) {
        let criterio={idOffer: gestorBD.mongo.ObjectID(req.params.idOffer), $or: [{author: res.user}, {vendor: res.user}]};

        // buscar los mensajes de la base de datos
        gestorBD.getMessages(criterio,function(messages) {
            if (messages==null) {
                res.status(500);
                res.json({
                    error : "Ha ocurrido un error al recuperar los mensaje"
                });
            } else if (messages.length===0) {
                res.status(200);
                res.json({
                    info : "No hay mensajes en la conversación"
                });
            } else {
                res.status(200);
                res.send( JSON.stringify(messages) );
            }
        });
    });

    /**
     * Elimina la conversación completa de una oferta concreta
     * El usuario debe estar autenticado
     * El usuario debe ser el interesado o el vendedor de la oferta
     */
    app.delete("/api/messages/delete/:idOffer", function(req, res) {
        let criterio = { idOffer: gestorBD.mongo.ObjectID(req.params.idOffer), $or: [{author: res.user}, {vendor: res.user}]};

        gestorBD.getMessages( criterio, function(messages) {
            if (messages == null || messages.length===0) {
                res.status(200);
                res.json({
                    info : "No hay mensajes en la conversación o no pertenecen al usuario autenticado"
                });
            } else {
                for (let elementMessage in messages) {
                    if (res.user!==messages[elementMessage].author && res.user!==messages[elementMessage].vendor) {
                        res.status(401);
                        res.json({
                            error : "Se debe ser el interesado o el vendedor de la oferta para borrar un mensaje"
                        });
                        return;
                    }
                    // borrar el mensaje de la base de datos
                    gestorBD.deleteMessage({_id: messages[elementMessage]._id}, function(message) {
                        if (message==null) {
                            res.status(500);
                            res.json({
                                error: "Se ha producido un error"
                            });
                            return;
                        }
                    });
                    logger.info(res.user+" ha eliminado el mensaje "+messages[elementMessage]._id);
                }
                res.status(200);
                res.send( JSON.stringify(messages) );
            }
        });
    });

    /**
     * Muestra el listado de mensajes de una conversación
     */
    app.put("/api/messages/read/:id", function(req, res) {
        let criterio = { "_id" : gestorBD.mongo.ObjectID(req.params.id) };
        gestorBD.getMessages(criterio,function(messages) {
            if ( messages == null ) {
                res.status(500);
                res.json({
                    error : "Se ha producido un error al recuperar el mensaje"
                });
                return;
            } else {
                if (res.user!==messages[0].author && res.user!==messages[0].vendor) {
                    res.status(401);
                    res.json({
                        error : "Se debe ser el interesado o el vendedor de la oferta para marcar como leído un mensaje"
                    });
                    return;
                }
                if (messages[0].read) {
                    res.status(200);
                    res.json({
                        mensaje : "El mensaje ya había sido marcado como leído con anterioridad",
                        _id : req.params.id
                    });
                    return;
                }
                gestorBD.updateMessage(criterio, {read: true}, function(result) {
                    if (result == null) {
                        res.status(500);
                        res.json({
                            error : "Se ha producido un error"
                        })
                    } else {
                        logger.info(res.user+" ha marcado como leido el mensaje "+req.params.id);
                        res.status(200);
                        res.json({
                            mensaje : "mensaje marcado como leido",
                            _id : req.params.id
                        })
                    }
                });
            }
        });

    });
}