module.exports = function(app, gestorBD, logger) {

    /**
     * Borra todos los datos de la Base de Datos
     * Excepto el usuario administrador
     */
    app.get("/deleteBD", function(req, res) {
        // borrar los usuarios
        gestorBD.getUsers({role: {$ne:"admin"}}, function(users) {
            for (let elementUser in users) {
                // borrar el usuario de la base de datos
                gestorBD.deleteUser({_id: users[elementUser]._id}, function(user) {
                    if (user!=null) {
                        // borrar las ofertas
                        gestorBD.getOffers({}, function(offers) {
                            for (let elementOffer in offers) {
                                // borrar la oferta de la base de datos
                                gestorBD.deleteOffer({_id: offers[elementOffer]._id}, function(offer) {});
                            }
                        });
                        // borrar los mensajes
                        gestorBD.getMessages({}, function(messages) {
                            for (let elementMessage in messages) {
                                // borrar los mensajes de la base de datos
                                gestorBD.deleteMessage({_id: messages[elementMessage]._id}, function(message) {});
                            }
                        });
                        logger.warn(req.session.user.email+" ha eliminado el usuario "+users[elementUser]._id);
                        res.redirect("/home");
                    }
                });
            }
        });
    });

    /**
     * Introduce datos de prueba en Base de Datos
     */
    app.get("/initBD", function(req, res) {
        // USUARIO 1
        seguro = app.get("crypto").createHmac('sha256', app.get('clave')).update("123456").digest('hex');
        user = {
            email: "susana@email.com",
            name: "Susana",
            surname: "Ivanov Villarejo",
            password : seguro,
            moneyAccount: 100.0,
            role: "standard"
        }
        gestorBD.addUser(user, function() {
            offer = {
                title: "Oferta 1",
                detail: "Descripción oferta 1",
                date: new Date(Date.now()).toDateString(),
                price: 10.0,
                sold: false,
                vendor: "susana@email.com",
                buyer: null
            }
            gestorBD.addOffer(offer, function() {
                offer = {
                    title: "Oferta 2",
                    detail: "Descripción oferta 2",
                    date: new Date(Date.now()).toDateString(),
                    price: 20.0,
                    sold: false,
                    vendor: "susana@email.com",
                    buyer: null
                }
                gestorBD.addOffer(offer, function() {
                    offer = {
                        title: "Oferta 3",
                        detail: "Descripción oferta 3",
                        date: new Date(Date.now()).toDateString(),
                        price: 30.0,
                        sold: false,
                        vendor: "susana@email.com",
                        buyer: null
                    }
                    gestorBD.addOffer(offer, function() {
                        // USUARIO 2
                        seguro = app.get("crypto").createHmac('sha256', app.get('clave')).update("123456").digest('hex');
                        user = {
                            email: "miriam@email.com",
                            name: "Miriam",
                            surname: "Aguayo Barrero",
                            password : seguro,
                            moneyAccount: 100.0,
                            role: "standard"
                        }
                        gestorBD.addUser(user, function() {
                            offer = {
                                title: "Oferta 4",
                                detail: "Descripción oferta 4",
                                date: new Date(Date.now()).toDateString(),
                                price: 40.0,
                                sold: false,
                                vendor: "miriam@email.com",
                                buyer: null
                            }
                            gestorBD.addOffer(offer, function() {
                                offer = {
                                    title: "Oferta 5",
                                    detail: "Descripción oferta 5",
                                    date: new Date(Date.now()).toDateString(),
                                    price: 50.0,
                                    sold: false,
                                    vendor: "miriam@email.com",
                                    buyer: null
                                }
                                gestorBD.addOffer(offer, function() {
                                    offer = {
                                        title: "Oferta 6",
                                        detail: "Descripción oferta 6",
                                        date: new Date(Date.now()).toDateString(),
                                        price: 60.0,
                                        sold: false,
                                        vendor: "miriam@email.com",
                                        buyer: null
                                    }
                                    gestorBD.addOffer(offer, function() {
                                        // USUARIO 3
                                        seguro = app.get("crypto").createHmac('sha256', app.get('clave')).update("123456").digest('hex');
                                        user = {
                                            email: "javier@email.com",
                                            name: "Javier",
                                            surname: "Romero Rial",
                                            password : seguro,
                                            moneyAccount: 100.0,
                                            role: "standard"
                                        }
                                        gestorBD.addUser(user, function() {
                                            offer = {
                                                title: "Oferta 7",
                                                detail: "Descripción oferta 7",
                                                date: new Date(Date.now()).toDateString(),
                                                price: 70.0,
                                                sold: false,
                                                vendor: "javier@email.com",
                                                buyer: null
                                            }
                                            gestorBD.addOffer(offer, function() {
                                                offer = {
                                                    title: "Oferta 8",
                                                    detail: "Descripción oferta 8",
                                                    date: new Date(Date.now()).toDateString(),
                                                    price: 80.0,
                                                    sold: false,
                                                    vendor: "javier@email.com",
                                                    buyer: null
                                                }
                                                gestorBD.addOffer(offer, function() {
                                                    offer = {
                                                        title: "Oferta 9",
                                                        detail: "Descripción oferta 9",
                                                        date: new Date(Date.now()).toDateString(),
                                                        price: 90.0,
                                                        sold: false,
                                                        vendor: "javier@email.com",
                                                        buyer: null
                                                    }
                                                    gestorBD.addOffer(offer, function() {
                                                        // USUARIO 4
                                                        seguro = app.get("crypto").createHmac('sha256', app.get('clave')).update("123456").digest('hex');
                                                        user = {
                                                            email: "cristobal@email.com",
                                                            name: "Cristobal",
                                                            surname: "Baena Magro",
                                                            password : seguro,
                                                            moneyAccount: 100.0,
                                                            role: "standard"
                                                        }
                                                        gestorBD.addUser(user, function() {
                                                            offer = {
                                                                title: "Oferta 10",
                                                                detail: "Descripción oferta 10",
                                                                date: new Date(Date.now()).toDateString(),
                                                                price: 100.0,
                                                                sold: false,
                                                                vendor: "cristobal@email.com",
                                                                buyer: null
                                                            }
                                                            gestorBD.addOffer(offer, function() {
                                                                offer = {
                                                                    title: "Oferta 11",
                                                                    detail: "Descripción oferta 11",
                                                                    date: new Date(Date.now()).toDateString(),
                                                                    price: 110.0,
                                                                    sold: false,
                                                                    vendor: "cristobal@email.com",
                                                                    buyer: null
                                                                }
                                                                gestorBD.addOffer(offer, function() {
                                                                    offer = {
                                                                        title: "Oferta 12",
                                                                        detail: "Descripción oferta 12",
                                                                        date: new Date(Date.now()).toDateString(),
                                                                        price: 120.0,
                                                                        sold: false,
                                                                        vendor: "cristobal@email.com",
                                                                        buyer: null
                                                                    }
                                                                    gestorBD.addOffer(offer, function() {
                                                                        // USUARIO 5
                                                                        seguro = app.get("crypto").createHmac('sha256', app.get('clave')).update("123456").digest('hex');
                                                                        user = {
                                                                            email: "domingo@email.com",
                                                                            name: "Domingo",
                                                                            surname: "March Mula",
                                                                            password : seguro,
                                                                            moneyAccount: 100.0,
                                                                            role: "standard"
                                                                        }
                                                                        gestorBD.addUser(user, function() {
                                                                            offer = {
                                                                                title: "Oferta 13",
                                                                                detail: "Descripción oferta 13",
                                                                                date: new Date(Date.now()).toDateString(),
                                                                                price: 130.0,
                                                                                sold: false,
                                                                                vendor: "domingo@email.com",
                                                                                buyer: null
                                                                            }
                                                                            gestorBD.addOffer(offer, function() {
                                                                                offer = {
                                                                                    title: "Oferta 14",
                                                                                    detail: "Descripción oferta 14",
                                                                                    date: new Date(Date.now()).toDateString(),
                                                                                    price: 140.0,
                                                                                    sold: false,
                                                                                    vendor: "domingo@email.com",
                                                                                    buyer: null
                                                                                }
                                                                                gestorBD.addOffer(offer, function() {
                                                                                    offer = {
                                                                                        title: "Oferta 15",
                                                                                        detail: "Descripción oferta 15",
                                                                                        date: new Date(Date.now()).toDateString(),
                                                                                        price: 150.0,
                                                                                        sold: false,
                                                                                        vendor: "domingo@email.com",
                                                                                        buyer: null
                                                                                    }
                                                                                    gestorBD.addOffer(offer, function() {
                                                                                        let message = {
                                                                                            author : "susana@email.com",
                                                                                            vendor : "domingo@email.com",
                                                                                            idOffer : offer._id,
                                                                                            text : "Hola",
                                                                                            date : new Date(Date.now()).toDateString(),
                                                                                            read : false
                                                                                        };
                                                                                        gestorBD.addMessage(message, function() {
                                                                                            logger.warn(req.session.user.email+" ha cargado datos de prueba en la base de datos");
                                                                                            res.redirect("/home");
                                                                                        });
                                                                                    });
                                                                                });
                                                                            });
                                                                        });
                                                                    });
                                                                });
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
}