module.exports = function(app, swig, logger) {
    /**
     * Muestra la vista por defecto (en este caso login)
     */
    app.get("/", function(req, res) {
        if (req.session.user==null) {
            let respuesta = swig.renderFile('views/users/login.html', {errors: req.session.errors});
            req.session.errors=null;
            res.send(respuesta);
        }
        else {
            res.redirect("/home");
        }
    });

    /**
     * Muestra la vista de home
     */
    app.get("/home", function(req, res) {
        let respuesta = swig.renderFile('views/home.html', {
            information: req.session.information, errors: req.session.errors, session: req.session.user
        });
        req.session.information=null;
        req.session.errors=null;
        res.send(respuesta);
    });
};