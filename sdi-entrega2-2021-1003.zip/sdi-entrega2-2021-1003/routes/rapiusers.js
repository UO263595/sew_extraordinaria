module.exports = function(app, gestorBD, logger) {

    /**
     * Inicia la sesión de un usuario
     * Tienen que introducirse el email y la contraseña
     */
    app.post("/api/login", function(req, res) {
        let seguro = app.get("crypto").createHmac('sha256', app.get('clave')).update(req.body.password).digest('hex');

        let criterio = {
            email : req.body.email,
            password : seguro
        };
        gestorBD.getUsers(criterio, function(users) {
            if (users == null || users.length === 0) {
                res.status(401); // Unauthorized
                res.json({
                    error: "Email o contraseña incorrectos",
                    autenticado : false
                });
            } else {
                let token = app.get('jwt').sign({usuario: criterio.email , tiempo: Date.now()/1000}, "secreto");
                logger.info(criterio.email+" se ha logueado");
                res.status(200);
                res.json({
                    info: "Usuario autenticado",
                    autenticado : true,
                    token : token
                });
            }
        })
    });
}