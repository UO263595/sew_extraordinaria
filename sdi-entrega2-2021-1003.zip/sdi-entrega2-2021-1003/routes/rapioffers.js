module.exports = function(app, gestorBD, logger) {

    /**
     * Muestra las ofertas existentes en la base de datos
     * Se omiten las del propio usuario y las que ya están vendidas
     * El usuario debe estar autenticado
     */
    app.get("/api/offers/list", function(req, res) {
        criterio = {vendor: {$ne: res.user}, sold: false};
        gestorBD.getOffers( criterio, function(offers) {
            if (offers == null) {
                res.status(500);
                res.json({
                    error : "Se ha producido un error"
                });
            } else {
                res.status(200);
                res.send( JSON.stringify(offers) );
            }
        });
    });

    /**
     * Muestra las ofertas propias existentes en la base de datos
     * El usuario debe estar autenticado
     */
    app.get("/api/offers/own/list", function(req, res) {
        criterio = {vendor: res.user, sold: false};
        gestorBD.getOffers( criterio, function(offers) {
            if (offers == null) {
                res.status(500);
                res.json({
                    error : "Se ha producido un error"
                });
            } else {
                res.status(200);
                res.send( JSON.stringify(offers) );
            }
        });
    });
}