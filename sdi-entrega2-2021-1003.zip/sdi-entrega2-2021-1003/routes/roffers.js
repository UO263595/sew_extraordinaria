module.exports = function(app, swig, gestorBD, logger) {
    /**
     * Muestra la vista de añadir oferta
     */
    app.get("/offers/add", function(req, res) {
        let respuesta = swig.renderFile('views/offers/add.html', {
            errors: req.session.errors, session: req.session.user
        });
        req.session.errors=null;
        res.send(respuesta);
    });

    /**
     * Inserta una nueva oferta en la base de datos
     * Si no hay errores se envía a la vista de lista de ofertas con un mensaje de información
     * Si hay errores se muestran en un mensaje en la vista de añadir oferta
     */
    app.post('/offers/add', function(req, res) {
        // Control de errores
        req.session.errors=[];
        // errores del título
        if (req.body.title.length===0) {
            req.session.errors.push({message : "Debe rellenar el campo de título", messageType : "alert-danger"});
        }
        if (req.body.title.length<3 || req.body.title.length>25) {
            req.session.errors.push({message : "El título debe contener entre 3 y 25 caracteres", messageType : "alert-danger"});
        }
        // errores del detalle
        if (req.body.detail.length===0) {
            req.session.errors.push({message : "Debe rellenar el campo de detalles", messageType : "alert-danger"});
        }
        if (req.body.detail.length<5 || req.body.detail.length>50) {
            req.session.errors.push({message : "El detalle debe contener entre 5 y 50 caracteres", messageType : "alert-danger"});
        }
        // errores del precio
        let price;
        if (req.body.price.length===0) {
            req.session.errors.push({message : "Debe rellenar el campo de precio", messageType : "alert-danger"});
        }
        else {
            price=Number.parseFloat(req.body.price);
            if (Number.isNaN(price)) {
                req.session.errors.push({message : "Error en el campo de precio", messageType : "alert-danger"});
            }
            if (price<=0) {
                req.session.errors.push({message : "El precio debe ser un número positivo", messageType : "alert-danger"});
            }
        }

        // si hay errores se envían los mensajes a la vista
        if (req.session.errors.length>0) {
            res.redirect("/offers/add");
            return;
        }

        // se crea la oferta
        let offer = {
            title: req.body.title,
            detail: req.body.detail,
            date: new Date(Date.now()).toDateString(),
            price: price,
            sold: false,
            vendor: req.session.user.email,
            buyer: null
        }

        // se inserta la oferta en la base de datos
        gestorBD.addOffer(offer, function(id) {
            if (id == null) {
                req.session.errors.push({message: "Ha ocurrido un error al insertar la oferta", messageType: "alert-danger"});
                res.redirect("/offers/add");
            } else {
                req.session.info = {message: "Nueva oferta añadida", messageType: "alert-info"};
                logger.info(req.session.user.email+" ha añadido la oferta "+id);
                res.redirect("/offers/list");
            }
        });
    });

    /**
     * Muestra la vista de listado de ofertas propias
     * Se omiten las ofertas ya vendidas
     */
    app.get("/offers/own/list", function(req, res) {
        let criterio={vendor: req.session.user.email, sold: false};
        // buscar las ofertas de la base de datos
        gestorBD.getOffers(criterio,function(offers) {
            if (offers==null) {
                req.session.errors=[{message: "Error al recuperar las ofertas", messageType: "alert-danger"}];
                res.redirect("/home");
            } else {
                offers.sort(function(a, b) {
                    if(a.title > b.title ) return 1;
                    if(a.title < b.title ) return -1;
                    return 0;
                });
                let respuesta = swig.renderFile('views/offers/own-list.html', {
                    offers: offers, errors: req.session.errors, information: req.session.information, session: req.session.user
                });
                req.session.information=null;
                req.session.errors=null;
                res.send(respuesta);
            }
        });
    });

    /**
     * Elimina la oferta seleccionada de la base de datos
     */
    app.post("/offers/delete/:id", function(req, res) {
        // se comprueba que la oferta no esté vendida y que el usuario autenticado es el vendedor
        let criterio = {_id: gestorBD.mongo.ObjectID(req.params.id), sold: false, vendor: req.session.user.email};
        // borrar la oferta de la base de datos
        gestorBD.deleteOffer(criterio, function(offer) {
            if (offer==null) {
                req.session.errors=[{message: "Error al eliminar la oferta", messageType: "alert-danger"}];
            }
            else {
                req.session.information=[{message: "Oferta eliminada con éxito", messageType: "alert-info"}];
                logger.info(req.session.user.email+" ha eliminado la oferta "+offer._id);
                // buscar los mensajes de la base de datos
                gestorBD.getMessages({idOffer: offer._id},function(messages) {
                    if (messages!=null) {
                        for (let elementMessage in messages) {
                            // borrar el mensaje de la base de datos
                            gestorBD.deleteMessage({_id: messages[elementMessage]._id}, function(message) {
                                if (message==null) {
                                    req.session.errors.push({message: "Error al eliminar el mensaje "+messages[elementMessage].title, messageType: "alert-danger"});
                                }
                            });

                        }
                    }
                });
            }
            res.redirect("/offers/own/list");
        });
    });

    /**
     * Muestra la vista de listado de ofertas
     */
    app.get("/offers/list", function(req, res) {
        let criterio={};
        // si se está realizando una búsqueda se añade el criterio
        if(req.query.search!=null) {
            criterio = { "title": {$regex: ".*"+req.query.search+".*", $options: 'i'} };
        }

        // paginación
        let pg=parseInt(req.query.pg);
        if (req.query.pg==null) {
            pg=1;
        }

        // buscar las ofertas de la base de datos
        gestorBD.getOffersPg(criterio, pg,function(offers, total) {
            if (offers==null) {
                req.session.errors=[{message: "Error al recuperar las ofertas", messageType: "alert-danger"}];
                res.redirect("/home");
            } else {
                let lastPg=total/5;
                if (total%5>0) {
                    lastPg=lastPg+1;
                }
                let pages = []; // páginas mostrar
                for (let i=pg-2 ; i<=pg+2 ; i++) {
                    if (i>0 && i<=lastPg) {
                        pages.push(i);
                    }
                }
                offers.sort(function(a, b) {
                    if(a.title > b.title ) return 1;
                    if(a.title < b.title ) return -1;
                    return 0;
                });
                let respuesta = swig.renderFile('views/offers/list.html', {
                    offers: offers, errors: req.session.errors, information: req.session.information,
                    session: req.session.user, pages: pages, current: pg
                });
                req.session.information=null;
                req.session.errors=null;
                res.send(respuesta);
            }
        });
    });

    /**
     * Compra la oferta seleccionada por el usuario autenticado
     * El comprador no puede ser el vendedor
     */
    app.post("/offers/buy/:id", function(req, res) {
        // se comprueba que la oferta no esté vendida y que el usuario autenticado no es el vendedor
        let criterioOffer = {_id: gestorBD.mongo.ObjectID(req.params.id), sold: false, vendor: {$ne: req.session.user.email}};
        gestorBD.getOffers(criterioOffer, function(offers) {
            if (offers[0]==null) {
                req.session.errors=[{message: "Error al comprar la oferta", messageType: "alert-danger"}];
                res.redirect("/offers/list");
            }
            else {
                if (offers[0].price<=req.session.user.moneyAccount) {
                    let updatedOffer = {
                        sold: true,
                        buyer: req.session.user.email
                    };
                    gestorBD.updateOffer(criterioOffer, updatedOffer, function(result) {
                       if (result == null) {
                           req.session.errors=[{message: "Error al comprar la oferta", messageType: "alert-danger"}];
                           res.redirect("/offers/list");
                       } else {
                           let criterioUser = {_id: gestorBD.mongo.ObjectID(req.session.user._id)};
                           let updatedUser = {
                             moneyAccount: req.session.user.moneyAccount-offers[0].price
                           };
                           gestorBD.updateUser(criterioUser, updatedUser, function(result) {
                               if (result == null) {
                                   req.session.errors=[{message: "Error al comprar la oferta", messageType: "alert-danger"}];
                                   res.redirect("/offers/list");
                               } else {
                                   req.session.user.moneyAccount=updatedUser.moneyAccount;
                                   req.session.information=[{message: "Oferta comprada con éxito", messageType: "alert-info"}];
                                   logger.info(req.session.user.email+" ha comprado la oferta "+offers[0]._id);
                                   res.redirect("/offers/list");
                               }
                           });
                       }
                    });
                } else {
                    req.session.errors=[{message: "No tienes suficiente saldo para comprar la oferta", messageType: "alert-danger"}];
                    res.redirect("/offers/list");
                }
            }
        });
    });

    /**
     * Muestra la vista de listado de ofertas compradas
     */
    app.get("/offers/buyed/list", function(req, res) {
        let criterio={buyer: req.session.user.email};
        // buscar las ofertas de la base de datos
        gestorBD.getOffers(criterio,function(offers) {
            if (offers==null) {
                req.session.errors=[{message: "Error al recuperar las ofertas", messageType: "alert-danger"}];
                res.redirect("/home");
            } else {
                let respuesta = swig.renderFile('views/offers/buyed-list.html', {
                    offers: offers, errors: req.session.errors, information: req.session.information, session: req.session.user
                });
                req.session.information=null;
                req.session.errors=null;
                res.send(respuesta);
            }
        });
    });
};